<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css" />
     <link rel="stylesheet" type="text/css" href="assets/css/main2.css" />
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <link rel="stylesheet" href="demo.css">
    <link rel="stylesheet" href="footer-distributed-with-address-and-phones.css">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

  <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">

  <link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="http://clubo7.com/xmlrpc.php" />


    <link rel="shortcut icon" href="http://clubo7.com/wp-content/uploads/2015/07/favicon.ico" />
 

<title>Entertainment | Club O7</title>
<link rel="alternate" type="application/rss+xml" title="Club O7 &raquo; Feed" href="http://clubo7.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Club O7 &raquo; Comments Feed" href="http://clubo7.com/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="Club O7 &raquo; Entertainment Comments Feed" href="http://clubo7.com/entertainment/feed/" />
    <script type="text/javascript">
      window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/clubo7.com\/wp-includes\/js\/wp-emoji-release.min.js"}};
      !function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
    </script>
    <style type="text/css">
img.wp-smiley,
img.emoji {
  display: inline !important;
  border: none !important;
  box-shadow: none !important;
  height: 1em !important;
  width: 1em !important;
  margin: 0 .07em !important;
  vertical-align: -0.1em !important;
  background: none !important;
  padding: 0 !important;
}
</style>
<link rel='stylesheet' id='amazing_hover_effects_css-css'  href='http://clubo7.com/wp-content/plugins/amazing-hover-effects/css/ihover.css' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://clubo7.com/wp-content/plugins/contact-form-7/includes/css/styles.css' type='text/css' media='all' />
<link rel='stylesheet' id='jquery.fancybox-css'  href='http://clubo7.com/wp-content/plugins/popup-with-fancybox/inc/jquery.fancybox.css' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://clubo7.com/wp-content/plugins/revslider/rs-plugin/css/settings.css' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}
</style>
<link rel='stylesheet' id='reset-css-css'  href='http://clubo7.com/wp-content/themes/clubo7design/css/reset.css' type='text/css' media='all' />
<link rel='stylesheet' id='wordpress-css-css'  href='http://clubo7.com/wp-content/themes/clubo7design/css/wordpress.css' type='text/css' media='all' />
<link rel='stylesheet' id='animation.css-css'  href='http://clubo7.com/wp-content/themes/clubo7design/css/animation.css' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://clubo7.com/wp-content/themes/clubo7design/css/magnific-popup.css' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-ui-css-css'  href='http://clubo7.com/wp-content/themes/clubo7design/css/jqueryui/custom.css' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css'  href='http://clubo7.com/wp-includes/js/mediaelement/mediaelementplayer.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='flexslider-css'  href='http://clubo7.com/wp-content/themes/clubo7design/js/flexslider/flexslider.css' type='text/css' media='all' />
<link rel='stylesheet' id='tooltipster-css'  href='http://clubo7.com/wp-content/themes/clubo7design/css/tooltipster.css' type='text/css' media='all' />
<link rel='stylesheet' id='odometer-theme-css'  href='http://clubo7.com/wp-content/themes/clubo7design/css/odometer-theme-minimal.css' type='text/css' media='all' />
<link rel='stylesheet' id='screen.css-css'  href='http://clubo7.com/wp-content/themes/clubo7design/css/screen.css' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='http://clubo7.com/wp-content/themes/clubo7design/css/font-awesome.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='custom_css-css'  href='http://clubo7.com/wp-content/themes/clubo7design/templates/custom-css.php' type='text/css' media='all' />
<link rel='stylesheet' id='google_font_default-css'  href='http://fonts.googleapis.com/css?family=Playfair+Display%3A400%2C700%2C400italic&#038;subset=latin%2Ccyrillic-ext%2Cgreek-ext%2Ccyrillic' type='text/css' media='all' />
<link rel='stylesheet' id='google_font0-css'  href='http://fonts.googleapis.com/css?family=Metrophobic%3A400%2C700%2C400italic&#038;subset=latin%2Ccyrillic-ext%2Cgreek-ext%2Ccyrillic' type='text/css' media='all' />
<link rel='stylesheet' id='google_font1-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400%2C700%2C400italic&#038;subset=latin%2Ccyrillic-ext%2Cgreek-ext%2Ccyrillic' type='text/css' media='all' />
<link rel='stylesheet' id='google_font2-css'  href='http://fonts.googleapis.com/css?family=Montserrat%3A400%2C700%2C400italic&#038;subset=latin%2Ccyrillic-ext%2Cgreek-ext%2Ccyrillic' type='text/css' media='all' />
<link rel='stylesheet' id='kirki-styles-css'  href='http://clubo7.com/wp-content/themes/clubo7design/modules/kirki/assets/css/kirki-styles.css' type='text/css' media='all' />
<link rel='stylesheet' id='tablepress-default-css'  href='http://clubo7.com/wp-content/tablepress-combined.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-css'  href='http://clubo7.com/wp-content/themes/clubo7design/css/grid.css' type='text/css' media='all' />
<script type='text/javascript' src='http://clubo7.com/wp-includes/js/jquery/jquery.js'></script>
<script type='text/javascript' src='http://clubo7.com/wp-includes/js/jquery/jquery-migrate.min.js'></script>
<script type='text/javascript' src='http://clubo7.com/wp-content/plugins/popup-with-fancybox/inc/jquery.fancybox.js'></script>
<script type='text/javascript' src='http://clubo7.com/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.tools.min.js'></script>
<script type='text/javascript' src='http://clubo7.com/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.revolution.min.js'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://clubo7.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://clubo7.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.2.4" />
<link rel='canonical' href='http://clubo7.com/entertainment/' />
<link rel='shortlink' href='http://clubo7.com/?p=4207' />   
  <style type="text/css">
    html,body {
  margin: 0;
  height: 100%;
  font-family: Arial, Helvetica, sans-serif;
}
.navbar{
      background-color: #000 ! important;
    }
    #navbarid a{
        color: white;
    }
    .navbar{
        overflow: hidden;
       background-color: black;
       padding: 1% 1%;
    }
    .navbar a {
       float: left;
       color: white;
         text-align: center;
         padding: 12px;
         text-decoration: none;
         font-size: 18px;
       line-height: 25px;
        border-radius: 4px;
    }
    .navbar a:hover {
        background-color:lightgreen;
      color: white;
    }
.p{
    word-wrap:break-word;
}
* {
  box-sizing: border-box;
}
.div1{
  border: 1px solid black;
  margin-bottom:12%;
  word-wrap: break-word;
  margin-top: 2%;
  padding:2%;
}
.container{
  min-height: 100%;
}
   p.a{
  font-family: "MV Boli", cursive;
}


  </style>
</head>
<body>

 
 <nav class="navbar navbar-expand-lg navbar-dark bg-black">
      <div class="container-fluid">
      <div><img src="../../photos/logo.jpg" style="width: 80%;height: 60px;"></div>
      <button class="navbar-toggler" data-toggle="collapse"data-target="#navbarid">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarid">
      <ul class="navbar-nav text-center ml-auto">
        <li class="nav-item">
          <a href="member_home.php" class="nav-link">Notice</a>
        </li>
        <li class="nav-item">
          <a href="../meeting/memberside_meeting.php" class="nav-link">Meeting</a>
        </li>
        <li class="nav-item">
          <a href="../password_reset/password_reset.php" class="nav-link">Password Reset</a>
        </li>
        <li class="nav-item">
          <a href="../logout/logout.php" class="nav-link">Logout</a>
        </li>        
      </ul>
      </div>
      </div>
    </nav>
    <?php
$db = mysqli_connect('localhost', 'root', '', 'meeting_server'); 
$results = mysqli_query($db, "SELECT * FROM descr"); ?>
<div class="container">
    <h1 class="text-center pt-5">Notice </h1>
    <div class="div1">
    <?php while ($row = mysqli_fetch_array($results)) { 
      echo nl2br($row['notice']);
      } ?>
    </div>
</div>
<div  class="one withsmallpadding ppb_header withbg parallax " style="background-image:url(http://clubo7.com/wp-content/uploads/2015/07/entertainment_tag_line.jpg);background-position: center top;text-align:center;padding:30px 0 30px 0;color:#ffffff;"  data-stellar-background-ratio="0.5" ><div class="standard_wrapper"><div class="page_content_wrapper"><div class="inner"><div class="page_header_sep center"></div><p></p>
<h2 class="center quote-txt">“ Joy, Fun &#038; Enjoyment ”</h2>
</div>
</div>
</div>
</div>
</body>
  <footer class="page-footer font-small bg-dark pt-4 margin-top-1" style="width:100%; left: 0px;bottom: 0px; ">
  <div class="container-fluid text-center text-md-left text-white ">
    <div class="row text-white" >

      <div class="col-md-4 mt-md-0 mt-3">
                     <h2 class="mx-2 font-italic text-warning "><p class="a">Evernet Technologies</h2></p>
 
          <p class="footer-links">
            <a href="#">Home</a>
            |
            <a href="#">About</a>
            |
            <a href="#">Contact</a>
          </p>

    <div class="footer-copyright text-left py-3 text-white" >© Copyright 2013. Evernet Technologies.
    

        <div style=" text-center" ><p>All Rights Reserved</p>
    </div>
    </div>
        </div>

        <hr class="clearfix w-100 d-md-none pb-3 ">

        <div class="col-md-4 mb-md-0 mb-3">

          <ul class="list-unstyled">
            <li>

            </li>
            <li>
              <p><i class="fa fa-map-marker"></i>
                <span> 2,Ishan Appartment</span> ,Gandhi Kunj Society<br /><span>Paldi, Ahmedabad-380007</span></p>
            </li>
            <li>
              <p><i class="fa fa-phone"></i>
                UK: +441162166224, India: 917778868367  </p>
            </li>
            <li>
              <p> <i class="fa fa-envelope"></i>
                <a href="info@evernet-tech.com">info@evernet-tech.com</a></p>
            </li>
          </ul>

        </div>

        <div class="col-md-4  mb-md-0 mb-3 ">

          <h5 class="text-uppercase">About the company</h5>
          <p> Lorem ipsum dolor sit amet, consectateur adispicing elit. Fusce euismod convallis velit, eu auctor lacus vehicula sit amet.</p>
          <p>
          <br />
        <a href="https://twitter.com/ClubO7India" target="_blank"><img src="http://clubo7.com//wp-content/uploads/2015/07/twitter.png"></a>
    <a href="https://www.youtube.com/channel/UCoLXtWVNLwm78F98sS2tSWQ" target="_blank"><img src="http://clubo7.com/wp-content/uploads/2015/07/youtube.png" ></a>
    <a href="https://www.linkedin.com/company/club-o7" target="_blank"><img src="http://clubo7.com/wp-content/uploads/2017/01/linkdin.png" ></a>
    <a href="https://www.instagram.com/clubo7/" target="_blank"><img src="http://clubo7.com/wp-content/uploads/2017/01/instagram.png"></a>
  </p>
<br />

        </div>
      
      </div>

    </div>

  </div>


</footer >

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
